import javax.swing.*;
import java.awt.event.*;

public class Comment extends JPanel {
	public Comment(String m) {
		
	}
}
